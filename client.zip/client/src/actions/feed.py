import os
import git
from src.actions.cross_action import CrossRepoActionBase
from src.actions.base import ActionBase
import json
class ShowFeedAction(CrossRepoActionBase):

    publish_locally = False
    user_feed_processed = []
    
    # --------------------------------------------------------
    # MAIN ENTRY POINT
    # ---------------------------------------------------------
    def run(self, args):
        target_handle = args.target_handle        # e.g. carl.social
        #Clone this Repo
        real_repo_path = self.ensure_real_repo_clone(target_handle, self.social_path)
        self.show_social_media(target_handle, real_repo_path)
    
    def show_social_media(self, target_handle, real_repo_path):
        if target_handle in self.user_feed_processed:
            return

        self.user_feed_processed.append(target_handle)

        # 1. Actions directory for this repo
        actions_dir = os.path.join(real_repo_path, "social", "actions")

        # Process posts, likes, replies here
        self.process_actions(actions_dir)

        # 2. Followers directory
        followers_dir = os.path.join(real_repo_path, "social", "following_repo")

        if not os.path.isdir(followers_dir):
            return

        # 3. Iterate through follower repos
        for follower_dir in os.listdir(followers_dir):
            follower_handle = follower_dir.replace("-", ".")   # e.g. lina-social → lina.social
            follower_repo_path = os.path.join(followers_dir, follower_dir)

            # Recurse into follower repo
            self.show_social_media(follower_handle, follower_repo_path)

    def process_actions(self, actions_dir):
        if not os.path.isdir(actions_dir):
            return

        for filename in os.listdir(actions_dir):
            if not filename.endswith(".json"):
                continue

            file_path = os.path.join(actions_dir, filename)

            try:
                with open(file_path, "r", encoding="utf-8") as f:
                    data = json.load(f)

                print(f"\n=== {filename} ===")
                print(json.dumps(data, indent=4))

            except Exception as e:
                print(f"Error reading {file_path}: {e}")




    # ---------------------------------------------------------
    # SHARED CROSS-REPO HELPER METHODS
    # ---------------------------------------------------------

    def get_nested_clone_path(self, handle):
        """
        Locate the nested clone inside:
        <active-identity-repo>/social/following_repos/<handle>-social/
        """
        repo_name = handle.replace(".social", "") + "-social"
        return os.path.join(self.social_path, "following_repos", repo_name)

    def get_repo_url_from_git_config(self, nested_clone_path):
        """
        Read the real repo URL from nested clone's .git/config.
        """
        repo = git.Repo(nested_clone_path)
        return repo.remotes.origin.url

    def ensure_real_repo_clone(self, handle, repo_url):
        """
        Ensure we have the REAL authoritative repo for the target user.
        This is at: <project_root>/<handle>-social/

        This is the repo we will write the LIKE into and push to GitHub.
        """
        project_root = os.path.dirname(os.path.dirname(self.social_path))

        # Step 2: Construct the real repo folder name
        repo_name = handle.replace(".social", "") + "-social"

        # Step 3: Build the full path to the real repo
        target_repo_path = os.path.join(project_root, repo_name)

        # Step 4: Clone or pull the real repo
        if not os.path.exists(target_repo_path):
            print(f"[CROSS-REPO] Cloning real repo: {repo_url}")
            git.Repo.clone_from(repo_url, target_repo_path)
        else:
            print(f"[CROSS-REPO] Pulling latest changes for {handle}")
            repo = git.Repo(target_repo_path)
            repo.remotes.origin.pull()

        return target_repo_path
